import OpenAI from "openai";
import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function POST(request: NextRequest) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "The site owner needs to add an OpenAI API key." }, { status: 500 });
    }
    const body = await request.json();
    if (!Array.isArray(body.messages) || body.messages.length === 0 || body.messages.length > 40) {
      return NextResponse.json({ error: "Please send a valid chat message." }, { status: 400 });
    }
    const messages = body.messages.map((m: { role?: string; content?: string }) => {
      if (!["user", "assistant"].includes(m.role || "") || typeof m.content !== "string") throw new Error("Invalid message format.");
      return { role: m.role as "user" | "assistant", content: m.content.slice(0, 12000) };
    });
    const result = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      messages: [
        { role: "system", content: "You are GogglGPT, a helpful, clear, friendly AI assistant. Answer accurately, explain uncertainty, and adapt explanations to the user's level. Do not claim to be ChatGPT or to use OpenAI's private internal code. Follow applicable safety rules." },
        ...messages
      ],
      temperature: 0.7
    });
    return NextResponse.json({ reply: result.choices[0]?.message?.content ?? "I couldn't generate a response." });
  } catch (error) {
    console.error("GogglGPT API error:", error);
    return NextResponse.json({ error: "GogglGPT couldn't respond. Check the API setup and try again." }, { status: 500 });
  }
}