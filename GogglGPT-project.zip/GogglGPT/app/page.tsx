"use client";
import { FormEvent, useState } from "react";
type Message = { role: "user" | "assistant"; content: string };

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function sendMessage(event: FormEvent) {
    event.preventDefault();
    const text = input.trim();
    if (!text || busy) return;
    const next: Message[] = [...messages, { role: "user", content: text }];
    setMessages(next); setInput(""); setError(""); setBusy(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Something went wrong.");
      setMessages([...next, { role: "assistant", content: data.reply }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach GogglGPT.");
    } finally { setBusy(false); }
  }

  return <main className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brandMark">G</div><span>GogglGPT</span></div>
      <button className="newChat" onClick={() => { setMessages([]); setError(""); }}>＋ New chat</button>
      <div className="sideNote">Your AI assistant</div>
      <div className="sideFooter">Powered by the OpenAI API</div>
    </aside>
    <section className="main">
      <header className="topbar"><span>GogglGPT</span><span className="status"><i /> AI assistant</span></header>
      <div className="conversation">
        {messages.length === 0 ? <div className="welcome">
          <div className="welcomeIcon">G</div><h1>What can I help with?</h1>
          <p>Ask a question, explore an idea, or get help with a project.</p>
          <div className="suggestions">
            {["Explain a tricky topic simply", "Help me brainstorm an idea", "Write or improve some code"].map(s =>
              <button key={s} onClick={() => setInput(s)}>{s}<span>↗</span></button>)}
          </div>
        </div> : <div className="messages">
          {messages.map((m, i) => <article className={`message ${m.role}`} key={i}>
            <div className="avatar">{m.role === "user" ? "Y" : "G"}</div><div className="messageText">{m.content}</div>
          </article>)}
          {busy && <article className="message assistant"><div className="avatar">G</div><div className="typing">GogglGPT is thinking…</div></article>}
        </div>}
      </div>
      <div className="composerWrap">
        {error && <div className="error">{error}</div>}
        <form className="composer" onSubmit={sendMessage}>
          <textarea value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); e.currentTarget.form?.requestSubmit(); } }}
            placeholder="Message GogglGPT…" rows={1} />
          <button className="send" type="submit" disabled={busy || !input.trim()} aria-label="Send message">↑</button>
        </form>
        <p className="disclaimer">GogglGPT can make mistakes. Check important information.</p>
      </div>
    </section>
  </main>;
}